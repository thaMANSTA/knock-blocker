# twitch-knock-blocker

A simple chrome extension which removes the intrusive "Knock" buttons on the twitch web UI.

## Open Chrome Extensions:

- Open Chrome and navigate to [chrome://extensions/](chrome://extensions/).

- Enable Developer Mode by toggling the switch in the upper-right corner.

## Load the Unpacked Extension:

- Click on “Load Unpacked” and select the “twitch-knock-blocker-extension” folder.

## Test on Twitch:

1. Navigate to a Twitch.tv page.

2. If there are any buttons with “Knock” in their text, they should now be hidden from view.

This simple extension modifies a webpage’s UI elements on the fly, feel free to
adjust the logic as needed based on updates to Twitch’s interface, please contribute ideas on
[GitHub](https://github.com/thaMANSTA/twitch-knock-blocker)!

## I need the Knock Buttons Back!

- You can simply disable this extension using the toggle in Manage Extensions!

